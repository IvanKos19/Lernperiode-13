# TypeScript Mini Projekt

Dieses Projekt dient als einfacher Einstieg in TypeScript.

## Funktionen
- Begrüsst Benutzer
- Rechnet einfache Zahlen zusammen
- Zeigt TypeScript-Typen in der Praxis

## Starten
npm install
npm run build
npm start
