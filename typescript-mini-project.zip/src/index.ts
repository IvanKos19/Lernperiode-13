// Einfache TypeScript-Funktionen

type User = {
  name: string;
  age: number;
};

function greetUser(user: User): string {
  return `Hallo ${user.name}, du bist ${user.age} Jahre alt.`;
}

function add(a: number, b: number): number {
  return a + b;
}

const user: User = { name: "Ivan", age: 18 };

console.log(greetUser(user));
console.log("5 + 3 =", add(5, 3));
